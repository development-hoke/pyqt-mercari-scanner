mercari-scanner.zipを圧縮解除し、mercari-scanner.exeを実行します。
windows10で使用することを推奨します。
画面上段にkeywordを入力して、下段のStartボタンを押して動作を開始します。
キーワードに該当する商品をwww.mercari.comで検索し、中央にあるテーブルに追加します。
いったんstartボタンを押した後には商品検索を継続的に遂行します。 登録されていない新商品が発見された場合は、リストに追加します。
stopボタンを押してmercariサイトへの検索動作を中止します。